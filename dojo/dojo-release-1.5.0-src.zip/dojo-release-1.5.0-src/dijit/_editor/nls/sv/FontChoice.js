({
	fontSize: "Storlek",
	fontName: "Teckensnitt",
	formatBlock: "Format",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "kursivt",
	fantasy: "fantasy",

	p: "Stycke",
	h1: "Rubrik",
	h2: "Underrubrik",
	h3: "Underunderrubrik",
	pre: "Förformaterat",

	1: "mycket, mycket litet",
	2: "mycket litet",
	3: "litet",
	4: "medelstort",
	5: "stort",
	6: "extra stort",
	7: "extra extra stort"
})