({
	createLinkTitle: "リンク・プロパティー",
	insertImageTitle: "イメージ・プロパティー",
	url: "URL:",
	text: "説明:",
	target: "ターゲット:",
	set: "設定",
	currentWindow: "現行ウィンドウ",
	parentWindow: "親ウィンドウ",
	topWindow: "最上位ウィンドウ",
	newWindow: "新規ウィンドウ"
})

