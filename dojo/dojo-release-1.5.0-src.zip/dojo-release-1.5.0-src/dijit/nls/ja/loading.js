({
	loadingState: "ロード中...",
	errorState: "エラーが発生しました。"
})
