({
	buttonOk: "确定",
	buttonCancel: "取消",
	buttonSave: "保存",
	itemClose: "关闭"
})
