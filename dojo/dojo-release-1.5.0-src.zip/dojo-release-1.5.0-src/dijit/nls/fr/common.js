({
	buttonOk: "OK",
	buttonCancel: "Annuler",
	buttonSave: "Sauvegarder",
	itemClose: "Fermer"
})
